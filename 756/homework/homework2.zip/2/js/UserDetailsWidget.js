// Wrap code with module pattern
var UserDetailsWidget = function()
{
    var global = this;

    // ///////////////////////////////
    // Widget Constructor Function //
    // ///////////////////////////////
    global.makeUserDetailsWidget = function(parentElement)
    {
        // //////////////////////
        // /// Fields /////
        // //////////////////////

        var container = parentElement;

        var userDetails;

        // ////////////////////////////
        // Private Instance Methods //
        // ////////////////////////////
        function getDetails()
        {
            var username = $("#user").html();
            parseNumbers;

            userDetails = $.ajax({
                url : "./getUser.php",
                type : "POST",
                data : {
                    username : username
                },
                async : false
            }).done(function(user)
            {

                // Update fields
                $(_.keys(user)).each(function()
                {
                    if ($("#" + this).attr("type") == "radio")
                    {
                        $("#" + this).prop("checked", user[this]);
                    } else if ($("#" + this).is("table"))
                    {
                        parseNumbers(user);
                    }
                });
            }).responseJSON;
        }

        var parseNumbers = function(user)
        {
            // Show the permissions granted to a user
            $(user.phone_numbers).each(function(id, number)
            {
                $("input[phoneNumberID=" + id + "]").prop("checked", true);
            });
        }

        function updateUserDetails()
        {
            var field = $(this).attr("id");

            var detail = userDetails[field];

            $("tr:has(#" + field + ")").toggleClass("selected",
                    detail != $(this).val());

            updateClickabilityOfButtons();
        }

        function updateClickabilityOfButtons()
        {
            var clickable = $(".selected").length > 0;

            $("#updateFieldsButton").prop("disabled", !clickable);
            $("#deleteNumberButton").prop("disabled", !clickable);
        }
        ;
        // ////////////////////////////////////////
        // Find Pieces and Enliven DOM Fragment //
        // ////////////////////////////////////////
        getDetails(userDetails);

        $("tr input[type!=button]").on("change input", updateUserDetails);

        // If it was meant to be permanent, disable it!
        $("tr.permanent input[type!=button][type!=submit]").prop("readonly",
                true);

        $("tr.permanent input[type=checkbox]").click(function()
        {
            return false;
        });

        $("#addNumberButton")
                .click(
                        function()
                        {
                            if ($("table#phone_numbers tr[new='new']").length > 0)
                                return;

                            var newNumber = $("<tr class=\"selected\">").attr('new', 'new');

                            newNumber
                                    .append('<td>\
                                            <input type="radio" name="phone_number" value="-1" id="phone_numbers" number_id="-1" class="phoneNumberBox" selected>\
                                            </td>');
                            newNumber
                                    .append('<td>\
                                            <span class="phone_type phone"><select id="type" name="type-1">\
                                            <option value="home">home</option>\
                                            <option value="office">office</option>\
                                            <option value="cell">cell</option>\
                                            <option value="other">other</option>\
                                            </select> </span>\
                                            <input class="phone_area_code phone" name="area_code-1" placeholder="Area Code" value="">\
                                            <input class="phone_number phone" name="number-1" placeholder="Telephone Number" value="">\
                                            </td>');

                            $("table#phone_numbers").append(newNumber);
                            
                            $("input#phone_numbers").click();
                            
                            updateClickabilityOfButtons();

                        });

        updateClickabilityOfButtons();
        
        document.onkeypress = function(e) {
            if(e.keyCode === 13) //if enter pressed
            {
                $("#updateFieldsButton").click();
            }

        }

        // ///////////////////////////
        // Public Instance Methods //
        // ///////////////////////////
        return {
            getRootEl : function()
            {
                return container;
            },
            update : function()
            {

            },
            log : function(message)
            {

            }
        };
    };
}();

$(document).ready(function()
{
    userDetailsWidget = makeUserDetailsWidget($("#content"));
});